import React from 'react'
import  Restaurant  from './component/Basics/Restaurant'
const App = () => {
  return (
    <Restaurant/>

  )
}
const App1 =()=>{
  return (
    <>
    <menuApi/></>
  )
}
export default App
