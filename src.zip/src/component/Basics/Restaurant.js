import React, { useState }from 'react'
import "./style.css"
import Menu from './menuApi'
import MenuCard from './MenuCard'
const Restaurant = () => {
    const[menuData, setMenuData]=useState(Menu);
    const filterItem=(category)=>{
    const updatesList=Menu.filter((curElem)=> {
      return curElem.category===category;

    });
    setMenuData(updatesList);
    };

return (
<> 
<navbar className="navbar">
    <div className="btn-group">
        <button className="btn-group__item" onClick={()=>filterItem("breakfast")}>Breakfast</button>
        <button className="btn-group__item" onClick={()=>filterItem("lunch")}>Lunch</button>
        <button className="btn-group__item"onClick={()=>filterItem("evening")}>Snacks</button>
        <button className="btn-group__item"onClick={()=>filterItem("dinner")}>Dinner</button>
        <button className="btn-group__item"onClick={()=>setMenuData(menuData)}>All</button>
    </div>

</navbar>

<MenuCard menuData={menuData}/>
</>
)
}

export default Restaurant
